#!/bin/bash

zip -FSr soln2.zip . -x ".*" -x "__MACOSX" -x "*Icon*" -x "assgn2.pdf"
