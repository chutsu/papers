function H_t = H(mf, y, mu_p, data)
    dx = mf(1) - mu_p(1);
    dy = mf(2) - mu_p(2);
    rp = sqrt(dx^2 + dy^2);  % predicted range
    
    % 1 - range, 2 - bearing, 3 - both
    switch(data.meas)
    case 1
        H_t = [-dx / rp, -dy / rp, 0];
    case 2
        H_t = [dy / rp^2, -dx / rp^2, -1];
    case 3
        H_t = [
            -dx / rp, -dy / rp, 0;
            dy / rp^2,-dx / rp^2, -1
        ];
    end
end