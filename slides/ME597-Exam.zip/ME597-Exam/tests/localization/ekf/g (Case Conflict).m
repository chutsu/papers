function G_t = G(u, x, dt, data)
    G_t = [
        1, 0, -u(1) * sin(x(3)) * dt;
        0, 1, u(1) * cos(x(3)) * dt;
        0, 0, 1
    ];
end
