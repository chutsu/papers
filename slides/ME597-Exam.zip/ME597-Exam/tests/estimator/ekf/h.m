function h_t = h(x, data)
	H = eye(3);
	h_t = H * x;
end
