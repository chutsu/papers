function H_t = H(y, data)
	H_t = eye(3);
end
