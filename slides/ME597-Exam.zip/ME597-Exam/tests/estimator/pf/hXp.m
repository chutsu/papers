function hXp_m = hXp(Xp_m)
    C = 1;

    hXp_m = C * Xp_m;
end
