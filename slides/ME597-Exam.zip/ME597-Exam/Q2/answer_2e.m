clear;
clc;
addpath('../lib/util');

% Simulation Initializations
Tf = 100;
dt = 1/ 2;
T = 0:dt:Tf;

% Motion model
delta_max = deg2rad(25); % max steering angle
L = 1;
x_t = [
    0; 
    0; 
    0;
    0;
    0
];
x_store = zeros(5, length(T));
x_store(:, 1) = x_t;
delta_store = zeros(1, length(T));
R = [
    0.001, 0, 0, 0, 0;   % x
    0, 0.001, 0, 0, 0;   % y
    0, 0, 0.0005, 0, 0;  % theta
    0, 0, 0, 0.01, 0;    % v
    0, 0, 0, 0, 0.0004;  % delta_t
];

% Measurement model
Q = [
    1, 0, 0, 0, 0;           % x
    0, 1, 0, 0, 0;           % y
    0, 0, deg2rad(2), 0, 0;  % theta
    0, 0, 0, 1, 0;           % v
    0, 0, 0, 0, deg2rad(2);  % delta_t
];

% Estimator
M = 10;  % Number of particles
X = zeros(length(R), M);
X(1:2,:) = 2 * rand(2, M) - 1;
X(3,:) = pi/4 * rand(1, M) - pi/8;
X(5,:) = pi/4 * rand(1, M) - pi/8;
mu_S  = zeros(length(R), length(T));
X_S = zeros(length(R), M, length(T));


% SIMULATE
for t = 1:length(T)    
    % inputs
    delta_t = 0.1 * sin(T(t) / 10) + 0.05 * cos(pi / 2 + T(t) / 16);
    if (delta_t > delta_max)
        delta_t = delta_max;
    elseif (delta_t < -delta_max)
        delta_t = -delta_max;
    end
    delta_store(t) = delta_t;
    v_t = 8;

    % update state
    x_t = bicycle_update(x_t, v_t, L, delta_t, dt);
    x_store(:, t + 1) = [
        x_t;
        v_t * sin(x_store(3, t));  % velocity
        delta_t  % steering
    ];
    
    if (t >= 3)
        % take measurement
        x_prev = x_store(:, t - 2);
        d = gaussian_noise(Q);
        y = x_prev + d;
        
        % sampling
        w = zeros(1, M);
        Xp = zeros(length(R), M);
        for m = 1:M
            % Xp
            e = gaussian_noise(R);
            Xp_m = [
                x_prev(1) + x_prev(4) * cos(x_prev(3)) * dt;
                x_prev(2) + x_prev(4) * sin(x_prev(3)) * dt;
                x_prev(3) + (x_prev(4) * tan(x_prev(5)) / L) * dt;
                x_prev(4);
                x_prev(5);
            ] + e;

            % hXp
            hXp = [
                Xp_m(1);
                Xp_m(2);
                Xp_m(3);
                Xp_m(4);
                Xp_m(5);
            ];
            Xp(:, m) = Xp_m;
            w(m) = max(1e-8, mvnpdf(y, hXp, Q));
        end

        % importance resampling
        W = cumsum(w);
        for m = 1:M
            seed = W(end) * rand(1);
            X(:, m) = Xp(:, find(W > seed, 1));
        end
    
        % record mean particle
        mu = [
            mean(X(1, :));
            mean(X(2, :));
            mean(X(3, :));
            mean(X(4, :));
            mean(X(5, :));
        ];
        
        S = var(X);
        mu_S(:, t) = mu;
        X_S(:, :, t) = X(:, :);

%         % Particle filter estimation
%         pf_mu_p_store(t) = pf.mu;
%         pf_S_store(t) = pf.S;
    end
end


% plot bicycle
% figure(1);
% clf;
% hold on;
% 
% plot(x_store(1, :), x_store(2, :), 'r');
% plot(mu_S(1, :), mu_S(2, :), 'b');
% for t = 1:50:length(T)
%     drawbox(1, x_store(1, t), x_store(2, t), x_store(3, t), 1);
%     
%     heading = sprintf('Heading = %f', rad2deg(x_store(3, t)));
%     text(x_store(1, t) + 2, x_store(2, t), heading);
%     
%     steering = sprintf('Steering = %f', delta_store(t));
%     text(x_store(1, t) + 2, x_store(2, t) - 3, steering);
% end
% title('Bicycle Trajectory');

figure(1);
clf;
hold on;

for t = 1:length(T)
    plot(x_store(1, 1:t), x_store(2, 1:t), 'r-');
    plot(mu_S(1, 1:t), mu_S(2, 1:t), 'b-');
%     pause(0.5);
    
    for i = 1:length(M)
       plot(X_S(1, i, t), X_S(2, i, t), 'b.'); 
    end
  
    if (mod(t, 50) == 0)
        drawbox(1, x_store(1, t), x_store(2, t), x_store(3, t), 1);

        heading = sprintf('Heading = %f', rad2deg(x_store(3, t)));
        text(x_store(1, t) + 2, x_store(2, t), heading);

        steering = sprintf('Steering = %f', delta_store(t));
        text(x_store(1, t) + 2, x_store(2, t) - 3, steering);
    end
    title('Bicycle Trajectory'); 
    drawnow;
end