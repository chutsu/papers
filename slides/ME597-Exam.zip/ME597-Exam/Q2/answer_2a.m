clear; clc; 
addpath(genpath('../lib'));

% simulation parameters
t_end = 100;
dt = 1 / 2;  % 2 Hz
T = 0:dt:t_end;

% bicycle
delta_max = deg2rad(25); % max steering angle
L = 1;
x_t = [0; 0; 0];
x_store = zeros(length(x_t), length(T));
x_store(:, 1) = x_t;
delta_store = zeros(1, length(T));


for t = 1:length(T)
    % update bicycle
    delta_t = 0.1 * sin(T(t) / 10) + 0.05 * cos(pi / 2 + T(t) / 16);
    if (delta_t > delta_max)
        delta_t = delta_max;
    elseif (delta_t < -delta_max)
        delta_t = -delta_max;
    end
    delta_store(t) = delta_t;
    v_t = 8;

    x_t = bicycle_update(x_t, v_t, L, delta_t, dt);
    x_store(:, t + 1) = x_t;
end


% plot bicycle
figure(1);
clf;
hold on;

plot(x_store(1, :), x_store(2, :), 'r');
for t = 1:10:length(T)
    drawbox(1, x_store(1, t), x_store(2, t), x_store(3, t), 1);
    
    heading = sprintf('Heading = %.2f', rad2deg(x_store(3, t)));
    text(x_store(1, t) + 2, x_store(2, t), heading);
    
    steering = sprintf('Steering = %.2f', delta_store(t));
    text(x_store(1, t) + 2, x_store(2, t) - 3, steering);
end

title('Bicycle Trajectory');