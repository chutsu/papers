clear;
clc;
addpath('../lib/util');

% Simulation Initializations
Tf = 100;
dt = 1/ 2;
T = 0:dt:Tf;

% Motion model
delta_max = deg2rad(25); % max steering angle
L = 1;
x_t = [
    0; 
    0; 
    0;
];
x_store = zeros(3, length(T));
x_store(:, 1) = x_t;
delta_store = zeros(1, length(T));
R = [
    0.001, 0, 0;   % x
    0, 0.001, 0;   % y
    0, 0, 0.0005;  % theta
];

% Measurement model
Q = [
    1, 0, 0;           % x
    0, 1, 0;           % y
    0, 0, deg2rad(2);  % theta
];

% Estimator
M = 10;  % Number of particles
X = zeros(length(R), M);
X(1:2,:) = 2 * rand(2, M) - 1;
X(3,:) = pi/8 * rand(1, M);
X0 = X;
mu_S  = zeros(length(R), length(T));
X_S = zeros(length(R), M, length(T));




% plot bicycle
figure(1);
clf;
hold on;


% SIMULATE
for t = 1:length(T)    
    % inputs
    delta_t = 0.1 * sin(T(t) / 10) + 0.05 * cos(pi / 2 + T(t) / 16);
    if (delta_t > delta_max)
        delta_t = delta_max;
    elseif (delta_t < -delta_max)
        delta_t = -delta_max;
    end
    delta_store(t) = delta_t;
    v_t = 8;

    % update state
    x_t = bicycle_update(x_t, v_t, L, delta_t, dt);
    x_store(:, t + 1) = x_t;
    
    % take measurement
    d = gaussian_noise(Q);
    y = x_t + d;
        
    % sampling
    w = zeros(1, M);
    Xp = zeros(length(R), M);
    for m = 1:M
        % Xp
        e = gaussian_noise(R);
        Xp_m = [
            X(1, m) + v_t * cos(X(3, m)) * dt;
            X(2, m) + v_t * sin(X(3, m)) * dt;
            X(3, m) + (v_t * tan(delta_t) / L) * dt;
        ] + e;
        if (Xp_m(3)) < 0
            Xp_m(3) = Xp_m(3) + 2*pi();
        end
        Xp_m(3) = mod(Xp_m(3), 2*pi());

        % hXp
        hXp = Xp_m;
        Xp(:, m) = Xp_m;
        w(m) = max(1e-8, mvnpdf(y, hXp, Q));
    end

    % importance resampling
    W = cumsum(w);
    for m = 1:M
        seed = W(end) * rand(1);
        X(:, m) = Xp(:, find(W > seed, 1));
    end
    
    % record mean particle
    mu = [
        mean(X(1, :));
        mean(X(2, :));
        mean(X(3, :));
    ];

    S = var(X);
    mu_S(:, t) = mu;
    X_S(:, :, t) = X(:, :);
end


% % plot bicycle
% figure(1);
% clf;
% hold on;
% 
% plot(x_store(1, :), x_store(2, :), 'r');
% plot(mu_S(1, :), mu_S(2, :), 'b');
% for t = 1:50:length(T)
%     drawbox(1, x_store(1, t), x_store(2, t), x_store(3, t), 1);
%     
%     heading = sprintf('Heading = %f', rad2deg(x_store(3, t)));
%     text(x_store(1, t) + 2, x_store(2, t), heading);
%     
%     steering = sprintf('Steering = %f', delta_store(t));
%     text(x_store(1, t) + 2, x_store(2, t) - 3, steering);
% end
% title('Bicycle Trajectory');
% 
figure(1);
clf;
hold on;
for t = 2:length(T)
    plot(x_store(1, 1:t), x_store(2, 1:t), 'r-');
    plot(mu_S(1, 1:t), mu_S(2, 1:t), 'b-');
    
    for i = 1:M
       plot(X_S(1, i, t), X_S(2, i, t), 'b.'); 
    end
  
    if (T(t) == 10 || T(t) == 30 || T(t) == 50 || T(t) == 70 || T(t) == 90 || T(t) == 100)
        drawbox(1, mu_S(1, t), mu_S(2, t), mu_S(3, t), 1);
        
        time = sprintf('Time = %.2f', T(t));
        text(mu_S(1, t) + 2, mu_S(2, t) + 3, time);

        heading = sprintf('Heading = %.2f', rad2deg(mu_S(3, t)));
        text(mu_S(1, t) + 2, mu_S(2, t), heading);

        steering = sprintf('Steering = %.2f', delta_store(t));
        text(mu_S(1, t) + 2, mu_S(2, t) - 3, steering);
    end
    title('Bicycle Trajectory'); 
    drawnow;
end