function G_t = G(u, x, dt, data)
	% length from wheel to center of chassis
	l = 0.3;

	% radius of wheel
	r = 0.25;

	% wheel constraints
	J_1 = [
		0, 1, l;
		-cos(pi / 6), -sin(pi / 6), l;
		cos(pi / 6), -sin(pi / 6), l;
	];

	% wheel radius
	J_2 = [
		r, 0.0, 0.0;
		0.0, r, 0.0;
		0.0, 0.0, r;
	];

	% constant terms
	C = inv(J_1) * J_2 * u * dt;

	% rotation matrix
	drot = [
		-sin(x(3)), cos(x(3)), 0;
		-cos(x(3)), -sin(x(3)), 0;
		0, 0, 0;
	];
	drot_C = drot * C;

	% fill in the jacobian matrix G
	G_t = eye(3);
	G_t(1:2, 3) = drot_C(1:2);
end
