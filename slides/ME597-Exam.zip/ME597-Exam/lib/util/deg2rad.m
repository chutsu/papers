function r = deg2rad(degrees)
    r = degrees * pi / 180.0;
end
