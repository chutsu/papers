function d = rad2deg(radians)
    d = radians * 180.0 / pi;
end
