function path = dijkstra(nodes, edges, start, finish)
    [spath, sdist] = shortest_path(2, nodes, edges, start, finish);
end