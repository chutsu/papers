% Question #1 - EKF SLAM with changing map

%% Map on day one
s = rng(10); % Fix randomness to a standard map.

%Store boundary
Ox = 1; Oy = 1; Lx = 24; Ly = 59;
store = [Ox Oy; Ox+Lx Oy; Ox+Lx Oy+Ly; Ox Oy+Ly; Ox Oy];
% Features
N = 100;
features =  [Ox + Lx*rand(N,1), Oy + Ly*rand(N,1),[1:N]']; %(x,y,label)
home = [1 1]; % Homing beacon location
% First map
map1 = features;

%% Find features on shelving that move
SOx = 5; SOy = 20; SLx = 10; SLy = 15;
shelving = [SOx SOy; SOx+SLx SOy; SOx+SLx SOy+SLy; SOx SOy+SLy; SOx SOy];
moved = inpolygon(features(:,1), features(:,2), shelving(:,1), shelving(:,2));
moved_ind = find(moved);
moved_features = features(moved_ind,:);
moved_features = [SOx+(moved_features(:,2)-SOy), SOy-(moved_features(:,1)-SOx), moved_features(:,3)];

% Find features in new shelving spot that disappear
moved_shelving = [SOx SOy-SLx; SOx+SLy SOy-SLx; SOx+SLy SOy; SOx SOy; SOx SOy-SLx]; 
missing = inpolygon(features(:,1), features(:,2), moved_shelving(:,1), moved_shelving(:,2));
missing_ind = find(missing);
missing_features = features(missing_ind,:);

% Find remaining fixed features
mv_ms = moved | missing;
fixed_ind = find(mv_ms==0);
fixed_features = [features(fixed_ind,:)];

% Create new features in empty space and throughout map
Mn = 10;
new_features =  [Ox + Lx*rand(Mn,1), Oy + Ly*rand(Mn,1), [N+1:N+Mn]'; ...
                 SOx + SLx*rand(Mn,1), SOy + SLy*rand(Mn,1), [N+Mn+1:N+2*Mn]'];

% Map on day two
map2 = [fixed_features; moved_features; new_features];


% Plotting of maps
figure(1); clf; 
subplot(121); hold on;
plot (store(:,1), store(:,2), 'g', 'LineWidth', 2);
plot (features(:,1), features(:,2),'bx','MarkerSize', 4);
plot (shelving(:,1), shelving(:,2), 'r', 'LineWidth', 1)
plot (home(1), home(2), 'mo', 'MarkerSize',6,'LineWidth', 2)
legend('Boundary', 'Features', 'Shelving', 'Home')
title('Feature map on Day 1')
axis equal
axis([0 30 0 75])

subplot(122); hold on;
plot (store(:,1), store(:,2), 'g', 'LineWidth', 2);
plot (fixed_features(:,1), fixed_features(:,2),'bx','MarkerSize', 4);
plot (moved_shelving(:,1), moved_shelving(:,2), 'r', 'LineWidth', 1)
plot (moved_features(:,1), moved_features(:,2),'rx','MarkerSize', 4);
plot (new_features(:,1), new_features(:,2),'gx','MarkerSize', 4);
plot (home(1), home(2), 'mo', 'MarkerSize',6,'LineWidth', 2)
title('Feature map on Day 2')
legend('Boundary','Fixed features', 'Moved Shelving','Moved features', 'New features', 'Home','Location', 'Best')
axis equal
axis([0 30 0 75])
