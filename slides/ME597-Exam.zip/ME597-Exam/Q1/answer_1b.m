% Question #1 - EKF SLAM with changing map
clear; clc; 
addpath('../lib/sensor');
addpath('../lib/util');

%% Map on day one
s = rng(10); % Fix randomness to a standard map.

%Store boundary
Ox = 1; Oy = 1; Lx = 24; Ly = 59;
store = [Ox Oy; Ox+Lx Oy; Ox+Lx Oy+Ly; Ox Oy+Ly; Ox Oy];
% Features
N = 100;
features =  [Ox + Lx*rand(N,1), Oy + Ly*rand(N,1),[1:N]']; %(x,y,label)
home = [1 1]; % Homing beacon location
% First map
map1 = features;

%% Find features on shelving that move
SOx = 5; SOy = 20; SLx = 10; SLy = 15;
shelving = [SOx SOy; SOx+SLx SOy; SOx+SLx SOy+SLy; SOx SOy+SLy; SOx SOy];
moved = inpolygon(features(:,1), features(:,2), shelving(:,1), shelving(:,2));
moved_ind = find(moved);
moved_features = features(moved_ind,:);
moved_features = [SOx+(moved_features(:,2)-SOy), SOy-(moved_features(:,1)-SOx), moved_features(:,3)];

% Find features in new shelving spot that disappear
moved_shelving = [SOx SOy-SLx; SOx+SLy SOy-SLx; SOx+SLy SOy; SOx SOy; SOx SOy-SLx]; 
missing = inpolygon(features(:,1), features(:,2), moved_shelving(:,1), moved_shelving(:,2));
missing_ind = find(missing);
missing_features = features(missing_ind,:);

% Find remaining fixed features
mv_ms = moved | missing;
fixed_ind = find(mv_ms==0);
fixed_features = [features(fixed_ind,:)];

% Create new features in empty space and throughout map
Mn = 10;
new_features =  [Ox + Lx*rand(Mn,1), Oy + Ly*rand(Mn,1), [N+1:N+Mn]'; ...
                 SOx + SLx*rand(Mn,1), SOy + SLy*rand(Mn,1), [N+Mn+1:N+2*Mn]'];

% Map on day two
map2 = [fixed_features; moved_features; new_features];

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% Time
Tf = 10;
dt = 1 / 5;  % 5 Hz
T = 0:dt:Tf;

% Motion model noise
R = [0.01, 0, 0;
     0, 0.01, 0;
     0, 0, 0.001];

% Measurement model and noise
rmax = 15;  % 15m max range
thmax = deg2rad(180);  % 180 degree FOV
Qi = 0.001;  % bearing additive noise



% Simulation Initializations
map = map1';
M = length(map);
n = length(R(:, 1));  % Number of vehicle states
xr = zeros(n, length(T));  % Vehicle states 
x0 = [1, 1, deg2rad(45)];
xr(:, 1) = x0;
N = n + 2 * M;
m = length(Qi(:, 1)); % Number of measurements per feature 
y = zeros(m * M, length(T)); % Measurements

% Prior over robot state
mu0r = [1; 1; deg2rad(45)];  % mean (mu)
S0rr = 0.00000000001 * eye(3);  % covariance (Sigma)

% Prior over feature map
mu0m = zeros(2 * M, 1);
S0mm = 100 * eye(2 * M);
newfeature = ones(M, 1);

mu = [mu0r; mu0m];  % belief of robot state and feature state
S = [S0rr zeros(n, 2 * M);  zeros(2 * M, n) S0mm];

mu_S = zeros(N,length(T)); % Belief
mu_S(:,1) = mu;

homing_beacon = [1, 1];


% Control inputs
u = zeros(2, length(T));

u(1,:) = 1;


% main loop
for t = 2:length(T)
    % Update robot state
    e = gaussian_noise(R);
    xr(:,t) = [
        xr(1, t - 1) + u(1, t) * cos(xr(3, t - 1)) * dt;
        xr(2, t - 1) + u(1, t) * sin(xr(3, t - 1)) * dt;
        xr(3, t - 1) + u(2, t) * dt ...
    ] + e;

    % Take measurements - for each feature
    flist = zeros(M, 1);  % list to track which features are detected
    for i = 1:M
        if (is_feature_inview(map(:, i), xr(:, t), rmax, thmax))
            flist(i) = 1;
            
            % Determine measurement
            d = gaussian_noise(Qi);
            y((2 * (i - 1) + 1):(2 * i), t) = [ ...
                range(homing_beacon, xr(:, t));
                bearing(map(:, i), xr(:, t))
            ] + d;
        end
    end
    
    %% Extended Kalman Filter Estimation
    % Prediction update
    mu(1:3) = [
        mu(1) + u(1, t) * cos(mu(3)) * dt;
        mu(2) + u(1, t) * sin(mu(3)) * dt;
        mu(3) + u(2, t) * dt
    ];
    Gt = [ 
        1, 0, -u(1, t) * sin(mu(3)) * dt;
        0, 1, u(1, t) * cos(mu(3)) * dt;
        0, 0, 1
    ];
    S(1:n, 1:n) = Gt * S(1:n, 1:n) * Gt' + R;

    % Measurement update
    for i = 1:M
        if (flist(i))
            % index of mu4 and mu5 (measurement x and y)
            mu4 = 3 + 2 * (i - 1) + 1;
            mu5 = 3 + 2 * i;
            
            % Feature initialization
            if (newfeature(i) == 1)
                mu(mu4) = y(2 * (i - 1) + 1, t);
                mu(mu5) = y(2 * i, t) + mu(3);
                newfeature(i) = 0;
            end

            % Linearization
            % predicted range
            dx = mu(mu4) - mu(1);
            dy = mu(mu5) - mu(2);
            rp = sqrt((dx)^2 + (dy)^2);

            % feature selector vector
            Fi = zeros(5, N); % N is nb of elements (nb vehicle states + 2 * nb features)
            Fi(1:n, 1:n) = eye(n);  % robot x, y, theta
            Fi(4:5, mu4:mu5) = eye(2);  % measurement x, y
            
            % linearization of measurement
            Ht = [ ...
                (-dx / rp), (-dy / rp), (0), (0), (0);  % range linearization
                (dy / rp^2), (-dx / rp^2), (-1), (-dy / rp^2), (dx / rp^2)  % bearing linearization
            ] * Fi;

            % Measurement update
            K = S * transpose(Ht) * inv(Ht * S * transpose(Ht) + Qi);
            I = y(2 * (i - 1) + 1:2*i, t) - [rp; (atan2(dy,dx) - mu(3))];
            mu = mu + K * I;
            S = (eye(n + 2 * M) - K * Ht) * S;
        end
    end
 
    % Store results
    mu_S(:,t) = mu;
end


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%


% Plotting of maps
figure(1); clf; 
subplot(121); hold on;
plot(store(:,1), store(:,2), 'g', 'LineWidth', 2);
plot(features(:,1), features(:,2),'bx','MarkerSize', 4);
plot(shelving(:,1), shelving(:,2), 'r', 'LineWidth', 1)
plot(home(1), home(2), 'mo', 'MarkerSize',6,'LineWidth', 2)
plot(xr(1, :), xr(2, :), 'rx');
plot(mu_S(1, :), mu_S(2, :), 'go');
% plot(mu_S(4, :), mu_S(5, :), 'cx');
legend('Boundary', 'Features', 'Shelving', 'Home')
title('Feature map on Day 1')
axis equal
axis([0 30 0 75])

% subplot(122); hold on;
% plot(store(:,1), store(:,2), 'g', 'LineWidth', 2);
% plot(fixed_features(:,1), fixed_features(:,2),'bx','MarkerSize', 4);
% plot(moved_shelving(:,1), moved_shelving(:,2), 'r', 'LineWidth', 1)
% plot(moved_features(:,1), moved_features(:,2),'rx','MarkerSize', 4);
% plot(new_features(:,1), new_features(:,2),'gx','MarkerSize', 4);
% plot(home(1), home(2), 'mo', 'MarkerSize',6,'LineWidth', 2)
% title('Feature map on Day 2')
% legend('Boundary','Fixed features', 'Moved Shelving','Moved features', 'New features', 'Home','Location', 'Best')
% axis equal
% axis([0 30 0 75])
