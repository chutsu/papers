% Question #1 - EKF SLAM with changing map
clear; clc; 
addpath('../lib/sensor');
addpath('../lib/util');

%% Map on day one
s = rng(10); % Fix randomness to a standard map.

%Store boundary
Ox = 1; Oy = 1; Lx = 24; Ly = 59;
store = [Ox Oy; Ox+Lx Oy; Ox+Lx Oy+Ly; Ox Oy+Ly; Ox Oy];
% Features
N = 100;
features =  [Ox + Lx*rand(N,1), Oy + Ly*rand(N,1),[1:N]']; %(x,y,label)
home = [1 1]; % Homing beacon location
% First map
map1 = features;

%% Find features on shelving that move
SOx = 5; SOy = 20; SLx = 10; SLy = 15;
shelving = [SOx SOy; SOx+SLx SOy; SOx+SLx SOy+SLy; SOx SOy+SLy; SOx SOy];
moved = inpolygon(features(:,1), features(:,2), shelving(:,1), shelving(:,2));
moved_ind = find(moved);
moved_features = features(moved_ind,:);
moved_features = [SOx+(moved_features(:,2)-SOy), SOy-(moved_features(:,1)-SOx), moved_features(:,3)];

% Find features in new shelving spot that disappear
moved_shelving = [SOx SOy-SLx; SOx+SLy SOy-SLx; SOx+SLy SOy; SOx SOy; SOx SOy-SLx]; 
missing = inpolygon(features(:,1), features(:,2), moved_shelving(:,1), moved_shelving(:,2));
missing_ind = find(missing);
missing_features = features(missing_ind,:);

% Find remaining fixed features
mv_ms = moved | missing;
fixed_ind = find(mv_ms==0);
fixed_features = [features(fixed_ind,:)];

% Create new features in empty space and throughout map
Mn = 10;
new_features =  [Ox + Lx*rand(Mn,1), Oy + Ly*rand(Mn,1), [N+1:N+Mn]'; ...
                 SOx + SLx*rand(Mn,1), SOy + SLy*rand(Mn,1), [N+Mn+1:N+2*Mn]'];

% Map on day two
map2 = [fixed_features; moved_features; new_features];

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

addpath('../lib/util');
addpath('../lib/plot');
addpath('../lib/sensor');
addpath('../lib/estimator/ekf');
addpath('plot');


% Time
Tf = 60;
dt = 1.0 / 5.0;
T = 0:dt:Tf;

% Initial Robot State
x0 = [2 2 0]';

% Control inputs
u = zeros(2, length(T));
u(1, :) = 1;
% u(2,:) = 0.3 * u(2, :);


% Motion Disturbance model
R = [0.01, 0, 0;
     0, 0.01, 0;
     0, 0, 0.001];

% Prior over robot state
mu0r = x0;  % mean (mu)
S0rr = 0.00000000001 * eye(3);  % covariance (Sigma)

% Feature Map
% map = [
%     -5:1:5, 5:-1:-5; 
%     -2 * ones(1, 11), 8 * ones(1, 11)
% ];
% M = length(map);
map = map1';
M = length(map);

% Prior over feature map
mu0m = zeros(2 * M, 1);
S0mm = 100 * eye(2 * M);
newfeature = ones(M, 1);

% Measurement model
rmax = 15;  % Max range
thmax = deg2rad(90);  % 1/2 Field of view

% Measurement noise
Qi = [
    0.00001, 0; 
    0, 0.00001
];

% Simulation Initializations
n = length(R(:, 1));  % Number of vehicle states
xr = zeros(n, length(T));  % Vehicle states 
xr(:, 1) = x0;
N = n + 2 * M;
m = length(Qi(:, 1)); % Number of measurements per feature 
y = zeros(m * M, length(T)); % Measurements

mu = [mu0r; mu0m];  % belief of robot state and feature state
S = [S0rr zeros(n, 2 * M);  zeros(2 * M, n) S0mm];
%S = [S0rr 100*ones(n,2*M);  100*ones(2*M,n) S0mm];

mu_S = zeros(N,length(T)); % Belief
mu_S(:,1) = mu;


%% go through first map
t = 1;

% main loop
for t = 2:length(T)
    % Update robot state
    if (t == 50)
        u(2, t:t+75) = 0.1;
    elseif (t == 260)
        u(2, t:t+120) = 0.12;
    end
    
    e = gaussian_noise(R);
    xr(:,t) = [
        xr(1, t - 1) + u(1, t) * cos(xr(3, t - 1)) * dt;
        xr(2, t - 1) + u(1, t) * sin(xr(3, t - 1)) * dt;
        xr(3, t - 1) + u(2, t) * dt ...
    ] + e;

    % Take measurements - for each feature
    flist = zeros(M, 1);  % list to track which features are detected
    for i = 1:M
        if (is_feature_inview(map(:, i), xr(:, t), rmax, thmax))
            flist(i) = 1;
            
            % Determine measurement
            d = gaussian_noise(Qi);
            y((2 * (i - 1) + 1):(2 * i), t) = [ ...
                range(map(:, i), xr(:, t));
                bearing(map(:, i), xr(:, t))
            ] + d;
        end
    end
    
    %% Extended Kalman Filter Estimation
    % Prediction update
    mu(1:3) = [
        mu(1) + u(1 ,t) * cos(mu(3)) * dt;
        mu(2) + u(1, t) * sin(mu(3)) * dt;
        mu(3) + u(2, t) * dt
    ];
    
    Gt = [ 
        1, 0, -u(1, t) * sin(mu(3)) * dt;
        0, 1, u(1, t) * cos(mu(3)) * dt;
        0, 0, 1
    ];
    
    S(1:n, 1:n) = Gt * S(1:n, 1:n) * Gt' + R;

    % Measurement update
    for i = 1:M
        if (flist(i))
            % index of mu4 and mu5 (measurement x and y)
            mu4 = 3 + 2 * (i - 1) + 1;
            mu5 = 3 + 2 * i;
            
            % Feature initialization
            if (newfeature(i) == 1)
                mu(mu4) = mu(1) + y(2 * (i - 1) + 1, t) * cos(y(2 * i, t) + mu(3));
                mu(mu5) = mu(2) + y(2 * (i - 1) + 1, t) * sin(y(2 * i, t) + mu(3));
                newfeature(i) = 0;
            end

            % Linearization
            % predicted range
            dx = mu(mu4) - mu(1);
            dy = mu(mu5) - mu(2);
            rp = sqrt((dx)^2 + (dy)^2);

            % feature selector vector
            Fi = zeros(5, N); % N is nb of elements (nb vehicle states + 2 * nb features)
            Fi(1:n, 1:n) = eye(n);  % robot x, y, theta
            Fi(4:5, mu4:mu5) = eye(2);  % measurement x, y
            
            % linearization of measurement
            Ht = [ ...
                (-dx / rp), (-dy / rp), (0), (dx / rp), (dy / rp);  % range linearization
                (dy / rp^2), (-dx / rp^2), (-1), (-dy / rp^2), (dx / rp^2)  % bearing linearization
            ] * Fi;

            % Measurement update
            K = S * transpose(Ht) * inv(Ht * S * transpose(Ht) + Qi);
            I = y(2 * (i - 1) + 1:2*i, t) - [rp; (atan2(dy,dx) - mu(3))];
            mu = mu + K * I;
            S = (eye(n + 2 * M) - K * Ht) * S;
        end
    end
 
    % Store results
    mu_S(:,t) = mu;

%     % Plot results
%     if (T(t) == 1 || T(t) == 10 || T(t) == 30 ||  T(t) == 60)
%         [newfeature] = plot_step(2, t, map, xr, mu, mu_S, S, y, newfeature);
%         T(t)
%         pause(5);
%     end
end


% plot first map
figure(1); clf; 
subplot(121); hold on;
plot(store(:,1), store(:,2), 'g', 'LineWidth', 2);
plot(features(:,1), features(:,2),'bx','MarkerSize', 4);
plot(shelving(:,1), shelving(:,2), 'r', 'LineWidth', 1)
plot(home(1), home(2), 'mo', 'MarkerSize',6,'LineWidth', 2)
plot(xr(1, :), xr(2, :), 'rx');
plot(mu_S(1, :), mu_S(2, :), 'go');
% plot(mu_S(4, :), mu_S(5, :), 'cx');
legend('Boundary', 'Features', 'Shelving', 'Home')
title('Feature map on Day 1')
axis equal
axis([0 30 0 75])


%% go through second map
t = 1;
map = map2';
xr(:, 1) = [2, 2, 0];
mu(1:3) = xr(:, 1);


% main loop
for t = 2:length(T)
    % Update robot state
    if (t == 50)
        u(2, t:t+75) = 0.1;
    elseif (t == 260)
        u(2, t:t+120) = 0.12;
    end
    
    e = gaussian_noise(R);
    xr(:,t) = [
        xr(1, t - 1) + u(1, t) * cos(xr(3, t - 1)) * dt;
        xr(2, t - 1) + u(1, t) * sin(xr(3, t - 1)) * dt;
        xr(3, t - 1) + u(2, t) * dt ...
    ] + e;

    % Take measurements - for each feature
    flist = zeros(M, 1);  % list to track which features are detected
    for i = 1:M
        if (is_feature_inview(map(:, i), xr(:, t), rmax, thmax))
            flist(i) = 1;
            
            % Determine measurement
            d = gaussian_noise(Qi);
            y((2 * (i - 1) + 1):(2 * i), t) = [ ...
                range(map(:, i), xr(:, t));
                bearing(map(:, i), xr(:, t))
            ] + d;
        end
    end
    
    %% Extended Kalman Filter Estimation
    % Prediction update
    mu(1:3) = [
        mu(1) + u(1 ,t) * cos(mu(3)) * dt;
        mu(2) + u(1, t) * sin(mu(3)) * dt;
        mu(3) + u(2, t) * dt
    ];
    
    Gt = [ 
        1, 0, -u(1, t) * sin(mu(3)) * dt;
        0, 1, u(1, t) * cos(mu(3)) * dt;
        0, 0, 1
    ];
    
    S(1:n, 1:n) = Gt * S(1:n, 1:n) * Gt' + R;
    
    
    % RANSAC
    nlls_max_iterations = 50;
    ransac_max_iterations = 100;
    sample = 5;
    inlier_threshold = 0.03;
    max_set_length = 0;
    max_set = [];
    mu0 = mu(1:3);
    r_size = zeros(1, ransac_max_iterations);
    r_error = zeros(1, ransac_max_iterations);
    meas_count = length(flist);
    meas_ind = find(flist);

    for k = 1:ransac_max_iterations
        % Initialize estimate
        mu_ransac = transpose(mu0);
        mu_s = zeros(3, nlls_max_iterations + 1);
        mu_s(:, 1) = mu_ransac;

        % Pick samples to use for solution
        sample_ind = ceil(meas_count * rand(sample, 1));

        % Solve NLLS to find robot position
        meas_sample = y(sample_ind);
        for m = 1:nlls_max_iterations
            H = zeros(length(sample), 3);
            rp = zeros(length(sample));
            thetap = zeros(length(sample));

            for n = 1:sample
                cur_pt = map(meas_ind(sample_ind(n)), :);

                % measurement model
                dx = cur_pt(1) - mu_ransac(1);
                dy = cur_pt(2) - mu_ransac(2);
                rp(n) = sqrt(dx^2 + dy^2);
                thetap(n) = atan2(dy, dx) - mu_ransac(3);

                % linearize measurement model
                H(n, :) = [ ...
                    (dy / rp(n)^2), ...
                    (-dx / rp(n)^2), ...
                    -1 ...
                ];
            end

            % solve non-linear least squares
            mu_ransac = mu_ransac + pinv(H) * (transpose(meas_sample) - transpose(thetap));
            mu_s(:, m + 1) = mu_ransac;
        end

        % Find inlier set
        inlier_set = [];
        for p = 1:meas_count
            if (find(sample_ind == p))
                inlier_set = [inlier_set; p];

            else
                cur_pt = map(meas_ind(p), :);

                % measurement model on belief vs measured
                dx = cur_pt(1) - mu_ransac(1);
                dy = cur_pt(2) - mu_ransac(2);
                thetac =  atan2(dy, dx) - mu_ransac(3);
                error = abs(meas_raw(p) - thetac);

                % check if error is within inlier threshold
                if (error < inlier_threshold)
                    inlier_set = [inlier_set; p];
                end            
            end
        end

        % Save biggest inlier set
        if (length(inlier_set) > max_set_length)
            max_set_length = length(inlier_set);
            max_set = inlier_set;
        end
        r_size(k) = length(inlier_set);
        r_error(k, :) = min(100, norm(mu_ransac - transpose(x0)));
    end

    % Measurement update
    for i = 1:M
        if (flist(i))
            % index of mu4 and mu5 (measurement x and y)
            mu4 = 3 + 2 * (i - 1) + 1;
            mu5 = 3 + 2 * i;
            
            % Feature initialization
            if (newfeature(i) == 1)
                mu(mu4) = mu(1) + y(2 * (i - 1) + 1, t) * cos(y(2 * i, t) + mu(3));
                mu(mu5) = mu(2) + y(2 * (i - 1) + 1, t) * sin(y(2 * i, t) + mu(3));
                newfeature(i) = 0;
            end

            % Linearization
            % predicted range
            dx = mu(mu4) - mu(1);
            dy = mu(mu5) - mu(2);
            rp = sqrt((dx)^2 + (dy)^2);

            % feature selector vector
            Fi = zeros(5, N); % N is nb of elements (nb vehicle states + 2 * nb features)
            Fi(1:n, 1:n) = eye(n);  % robot x, y, theta
            Fi(4:5, mu4:mu5) = eye(2);  % measurement x, y
            
            % linearization of measurement
            Ht = [ ...
                (-dx / rp), (-dy / rp), (0), (dx / rp), (dy / rp);  % range linearization
                (dy / rp^2), (-dx / rp^2), (-1), (-dy / rp^2), (dx / rp^2)  % bearing linearization
            ] * Fi;

            % Measurement update
            K = S * transpose(Ht) * inv(Ht * S * transpose(Ht) + Qi);
            I = y(2 * (i - 1) + 1:2*i, t) - [rp; (atan2(dy,dx) - mu(3))];
            mu = mu + K * I;
            S = (eye(n + 2 * M) - K * Ht) * S;
        end
    end
 
    % Store results
    mu_S(:,t) = mu;

%     % Plot results
%     if (T(t) == 1 || T(t) == 10 || T(t) == 30 ||  T(t) == 60)
%         [newfeature] = plot_step(2, t, map, xr, mu, mu_S, S, y, newfeature);
%         T(t)
%         pause(5);
%     end
end



%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%


% Plotting second map
subplot(122); hold on;
plot(store(:,1), store(:,2), 'g', 'LineWidth', 2);
plot(fixed_features(:,1), fixed_features(:,2),'bx','MarkerSize', 4);
plot(moved_shelving(:,1), moved_shelving(:,2), 'r', 'LineWidth', 1)
plot(moved_features(:,1), moved_features(:,2),'rx','MarkerSize', 4);
plot(new_features(:,1), new_features(:,2),'gx','MarkerSize', 4);
plot(home(1), home(2), 'mo', 'MarkerSize',6,'LineWidth', 2);
plot(xr(1, :), xr(2, :), 'rx');
plot(mu_S(1, :), mu_S(2, :), 'go');
title('Feature map on Day 2')
legend('Boundary','Fixed features', 'Moved Shelving','Moved features', 'New features', 'Home','Location', 'Best')
axis equal
axis([0 30 0 75])
