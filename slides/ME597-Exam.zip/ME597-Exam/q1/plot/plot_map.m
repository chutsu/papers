function plot_map(map)
    plot(map(1, :), map(2, :), 'go', 'MarkerSize', 10, 'LineWidth', 2);
end