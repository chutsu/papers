function [ output_args ] = plot_cov( input_args )
%PLOT_COV Summary of this function goes here
%   Detailed explanation goes here


end

