% Question 3 - Aerial Drone Racing Map
clear; clc; close all;

s = rng(10); % Fix randomness to a standard course.

% Course Map
env = [100 100; 1100 100; 1100 600; 100 600; 100 100];
box = [400 250; 800 250; 800 450; 400 450; 400 250];
map = [env; NaN NaN; box];
line = [600 100; 600 250]; % Start and finish line
x0 = [600 175]; % Starting position

figure(1); clf; hold on;
plot (line(:,1), line(:,2), 'g', 'LineWidth', 4);
plot (map(:,1), map(:,2),'b','LineWidth', 4);
axis([0 1200 0 700])
axis equal

% Obstacles in circle format
% Circles = [x_c, y_c, r_c];
n_c = 15; % Number of obstacles
i = 0;
circles = [];
while (i < n_c)
    % Select a new circle object to add
    p_c = [100 100] + [1000 500].* rand(1,2); % circle centre
    r_c = 10 + 40 * rand(1,1); % circle radius
    % Reject if in collision with boundaries
    if ((Dist2Poly(p_c(1), p_c(2), box(:,1), box(:,2)) > r_c) ...
        && (Dist2Poly(p_c(1), p_c(2), env(:,1), env(:,2)) < -(r_c+10)) ...
        && (norm(p_c - x0,2) > r_c))
        if (Dist2Poly(p_c(1), p_c(2), env(:,1), env(:,2))+r_c > 0)
            break;
        end
        % Reject if in collision with other obstacles
        incollision = 0;
        for j = 1:i
            if(norm(p_c - circles(j,1:2),2) < r_c+circles(j,3))
                incollision = 1;
            end
        end
        % Add new circle and plot
        if (~incollision)
            circles = [circles; p_c, r_c];
            i = i+1;
            viscircles(p_c, r_c,'EdgeColor', 'b');
        end
    end
end

