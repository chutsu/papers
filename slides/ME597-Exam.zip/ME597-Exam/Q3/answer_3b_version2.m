clear; clc; 

% quadrotor param
m = 1;
g = 9.8;
K_h = 0.07;  % drag coefficient


% simulation params
dt = 0.01;
Tend = 40;
T = 0:dt:Tend;
x_store = zeros(4, length(T));
x_t = [
    75;  % x
    0;  % y
    0;  % v_x
    0   % v_y
];

phi = 0;  % roll
psi = 0;  % pitch

% P D
k_p = 0.6;
k_i = 0.01;
k_d = 1;


x_prev_error = 0;
y_prev_error = 0;
phi_error_sum = 0;
phi_prev_error = 0;
psi_error_sum = 0;
psi_prev_error = 0;

figure(1);
clf;
hold on;

% build trajectory
r = 150 / 2;
trajectory = zeros(2, 3600);
for i = 1:3600
    theta = deg2rad(i / 10);
    trajectory(:, i) = [
        r * cos(theta);
        r * sin(theta);    
    ];
end
waypoint_index = 1;

for t = 1:length(T)
    % waypoint
    waypoint = trajectory(:, waypoint_index);
    dist = sqrt((waypoint(2) - x_t(2))^2 + (waypoint(1) - x_t(1))^2);
    if (dist < 2)
        waypoint_index = waypoint_index + 1;
    end 
   
    % phi controller
    phi_desired = waypoint(1);
    phi_error = (phi_desired - x_t(1));
    phi_error_sum = phi_error_sum + phi_error;
    phi = k_p * phi_error + k_d * abs(phi_prev_error - phi_error) + k_i * phi_error_sum * dt;
    phi_prev_error = phi_error;
    if phi >= deg2rad(60)
        phi = deg2rad(60);
    elseif phi <= deg2rad(-60)
        phi = deg2rad(-60);
    end

    % psi controller
    psi_desired = waypoint(2);
    psi_error = (psi_desired - x_t(2));
    p =  k_p * psi_error
    d = (psi_prev_error - psi_error)
    psi = k_p * psi_error + k_d * (psi_prev_error - psi_error);
    psi_prev_error = psi_error;
    if psi >= deg2rad(10)
        psi = deg2rad(10);
    elseif psi <= deg2rad(-10)
        psi = deg2rad(-10);
    end
    
    % input
    u_t = [
        ((m * g / cos(phi)) * sin(phi) - (K_h * dt) * x_t(1)^2) / m;
        ((m * g / cos(psi)) * sin(psi) - (K_h * dt) * x_t(2)^2) / m;
    ];


    % motion model
    x_t = [
        x_t(1) + x_t(3) * dt;
        x_t(2) + x_t(4) * dt;
        x_t(3) + u_t(1) * dt;
        x_t(4) + u_t(2) * dt;
    ];
    x_store(:, t) = x_t;
    
%     subplot(4, 1, 1);
%     hold on;
%     plot(x_t(1), x_t(2), 'r.');
%     title('State');
%     axis equal;
%     
%     subplot(4, 1, 2);
%     hold on;
%     plot(t, x_t(3), 'r.');
%     title('Roll Velocity');
%     
%     subplot(4, 1, 3);
%     hold on;
%     plot(t, u_t(1), 'r.');
%     title('Roll Aceleration');
%     
%     subplot(4, 1, 4);
%     hold on;
%     plot(t, rad2deg(phi), 'r.');
%     title('Roll Angle');
% 
%     drawnow;
end

hold on;
plot(x_store(1, :), x_store(2, :), 'r.');
plot(trajectory(1, :), trajectory(2, :), 'g-');
title('State');
axis equal;
