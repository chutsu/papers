clear; 
clc; 
close all;
addpath(genpath('../lib'));

% simulation parameters
t_end = 200;
dt = 1 / 10;  % 10 hz
T = 0:dt:t_end;

% bicycle states
L = 1.0;
delta_max = deg2rad(25); % max steering angle
x_t = [
    75;  % x
    0;  % y
    deg2rad(90);  % theta
];
x_store = zeros(length(x_t), length(T));
x_store(:, 1) = x_t;

% build trajectory
r = 150 / 2;
waypoints = zeros(2, 720);
for i = 1:720
    theta = deg2rad(i);
    waypoints(:, i) = [
        r * cos(theta);
        r * sin(theta);
    ];
end
waypoints = waypoints';
wp_index = 1;

% carrot states
carrot_t = [
    0;  % x
    0;  % y
];
carrot_store = zeros(length(carrot_t), length(T));
carrot_store(:, 1) = carrot_t;
v_t = 15;

% simulation
for i = 1:length(T)
    % update carrot
    [carrot_t, wp_index] = carrot_update( ...
        x_t, ...
        1, ...
        waypoints, ...
        wp_index ...
    );
    carrot_store(:, i) = carrot_t;
    if wp_index == length(waypoints);
        break
    end

    % update steering
    delta_t = calculate_delta(x_t, carrot_t, delta_max);

    % update bicycle
    x_t = bicycle_update(x_t, v_t, L, delta_t, dt);
    x_store(:, i + 1) = x_t;
end

figure(1);
clf;
hold on;

subplot(2, 1, 1);
hold on;
plot(x_store(1, 2:end), x_store(2, 2:end), 'rx');
for i = 1:10:length(T)
    drawbox(1, x_store(1, i), x_store(2, i), x_store(3, i), 1.0);
end
plot(carrot_store(1, 2:end), x_store(2, 2:end), 'go');
axis([-80, 80, -80, 80]);
xlabel('position x (m)');
ylabel('position y (m)');

subplot(2, 1, 2);
hold on;
plot(x_store(1, 2:end), x_store(2, 2:end), 'rx');
for i = 1:10:length(T)
    drawbox(1, x_store(1, i), x_store(2, i), x_store(3, i), 1.0);
end
plot(carrot_store(1, 2:end), x_store(2, 2:end), 'go');
axis([50, 80, -45, -5]);
xlabel('position x (m)');
ylabel('position y (m)');
