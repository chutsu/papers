clear; clc; 

% quadrotor param
m = 1;
g = 9.8;
K_h = 0.07;  % drag coefficient


% simulation params
dt = 0.01;
Tend = 2;
T = 0:dt:Tend;
x_t = [
    0;  % x
    0;  % y
    0;  % v_x
    0   % v_y
];

phi = 0;  % roll
psi = 0;  % pitch

k_p = 0.1;
k_i = 0.1;
k_d = 0.2;


x_prev_error = 0;
y_prev_error = 0;
xpos_error_sum = 0;
phi_error_sum = 0;
phi_prev_error = 0;
psi_error_sum = 0;
psi_prev_error = 0;


figure(1);
clf;
hold on;

for t = 1:length(T)
    destination = [1, 1];
    
%     % x position controller
    kp_xpos = 1;
    kd_xpos = 0;
    ki_xpos = 0;
    x_desired = destination(1);
    x_error = (x_desired - x_t(1));
    xpos_error_sum = xpos_error_sum + x_error;
%     x = kp_xpos * x_error + k_d * (x_prev_error - x_error) + k_i * xpos_error_sum;
    x = (kp_xpos * x_error);
    x_prev_error = x_error;

%     % y position controller
%     y_desired = destination(2);
%     y_error = (y_desired - x_t(2));
%     y = k_p * y_error + k_d * (x_t(2) - y_prev_error);
%     y_prev_error = y_error;
    
    % phi atitude controller
    phi_desired = x;
    phi_error = (phi_desired - phi);
    phi_error_sum = phi_error_sum + phi_error;
    phi = k_p * phi_error + k_d * (phi - phi_prev_error);
    phi_prev_error = phi_error;
    if phi >= deg2rad(60)
        phi = deg2rad(60);
    elseif phi <= deg2rad(-60)
        phi = deg2rad(-60);
    end

    % psi atitude controller
    psi_desired = 0;
    psi_error = (psi_desired - psi);
    psi = k_p * psi_error + k_d * (psi - psi_prev_error);
    psi_prev_error = psi_error;
    if psi >= deg2rad(60)
        psi = deg2rad(60);
    elseif psi <= deg2rad(-60)
        psi = deg2rad(-60);
    end
    
    % input
    u_t = [
        (((m * g) / cos(phi)) * sin(phi) - (K_h * dt) * x_t(1)^2) / m;
        (((m * g) / cos(psi)) * sin(psi) - (K_h * dt) * x_t(2)^2) / m;
    ];

    % motion model
    x_t = [
        x_t(1) + x_t(3) * dt;
        x_t(2) + x_t(4) * dt;
        x_t(3) + u_t(1) * dt;
        x_t(4) + u_t(2) * dt;
    ];

    subplot(3, 1, 1);
    hold on;
    plot(x_t(1), x_t(2), 'b.');
    title('state');
    
    subplot(3, 1, 2);
    hold on;
    plot(t, u_t(1), 'b.');
    title('Roll Aceleration');
    
    subplot(3, 1, 3);
    hold on;
    plot(t, rad2deg(phi), 'b.');
    title('Roll Angle');
   
    drawnow;
end