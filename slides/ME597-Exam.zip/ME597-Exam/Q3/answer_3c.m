% % Question 3 - Aerial Drone Racing Map
% % clear; 
% % clc; 
% % close all;
% 
% s = rng(10); % Fix randomness to a standard course.
% 
% % Course Map
% env = [100 100; 1100 100; 1100 600; 100 600; 100 100];
% box = [400 250; 800 250; 800 450; 400 450; 400 250];
% map = [env; NaN NaN; box];
% line = [600 100; 600 250]; % Start and finish line
% x0 = [600 175]; % Starting position
% 
% figure(1); clf; hold on;
% plot (line(:,1), line(:,2), 'g', 'LineWidth', 4);
% plot (map(:,1), map(:,2),'b','LineWidth', 4);
% axis([0 1200 0 700])
% axis equal
% 
% % Obstacles in circle format
% % Circles = [x_c, y_c, r_c];
% n_c = 15; % Number of obstacles
% i = 0;
% circles = [];
% while (i < n_c)
%     % Select a new circle object to add
%     p_c = [100 100] + [1000 500].* rand(1,2); % circle centre
%     r_c = 10 + 40 * rand(1,1); % circle radius
%     % Reject if in collision with boundaries
%     if ((Dist2Poly(p_c(1), p_c(2), box(:,1), box(:,2)) > r_c) ...
%         && (Dist2Poly(p_c(1), p_c(2), env(:,1), env(:,2)) < -(r_c+10)) ...
%         && (norm(p_c - x0,2) > r_c))
%         if (Dist2Poly(p_c(1), p_c(2), env(:,1), env(:,2))+r_c > 0)
%             break;
%         end
%         % Reject if in collision with other obstacles
%         incollision = 0;
%         for j = 1:i
%             if(norm(p_c - circles(j,1:2),2) < r_c+circles(j,3))
%                 incollision = 1;
%             end
%         end
%         % Add new circle and plot
%         if (~incollision)
%             circles = [circles; p_c, r_c];
%             i = i+1;
%             viscircles(p_c, r_c,'EdgeColor', 'b');
%         end
%     end
% end
% 

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

addpath('plot');
addpath(genpath('../lib'));
close all

% parameters
nb_samples = 1000;
dxy = 1;
map_offset = [100, 100];
pos_start = [x0(1) - map_offset(1) - 7, x0(2) - map_offset(2), pi];
pos_end = [x0(1) - map_offset(1) + 6, x0(2) - map_offset(2)];

% prm
[map, map_min, map_max] = load_omap('map_final.jpg');
milestones = prm_sample(nb_samples,...
	map,...
	pos_start,...
	pos_end,...
	map_min,... 
	map_max ...
);
[spath, sdist] = prm_search(map, milestones, 50, 1, 2);
plot_omap(1, map, pos_start, pos_end, 0.1);
plot_milestones(1, milestones);
for i = 1:length(spath) - 1
    plot([spath(i, 1), spath(i + 1, 1)], ...
        [spath(i, 2), spath(i + 1, 2)], ...
        'go-', ...
        'LineWidth', 3, ...
        'markersize', 5 ...
    );
end
disp(sdist);

% simulation parameters
t_end = 200;
dt = 0.01;  % 10 Hz
t = 0:dt:t_end;

% waypoints
waypoints = double(spath);

% model parameters
L = 0.3;
stddev_x = 0.02;
stddev_y = 0.02;
stddev_theta = deg2rad(1.0);
v_t = 15;
 
% bicycle states
delta_max = deg2rad(25); % max steering angle
x_t = [
    pos_start(1);  % x
    pos_start(2);  % y
    pos_start(3);  % theta
];
x_store = zeros(length(x_t), length(t));
x_store(:, 1) = x_t;

% carrot states
carrot_t = [
    0;  % x
    0;  % y
];
carrot_store = zeros(length(carrot_t), length(t));
carrot_store(:, 1) = carrot_t;

% control parameters
k = 2.0;

% controller states
c_t = (0);  % heading error
c_store = zeros(length(c_t), length(t));
c_store(:, 1) = c_t;

% simulation
wp_index = 1;
delta_t = 0;
start = 0;

for i = 1:length(t)
    % update carrot
    [carrot_t, wp_index] = carrot_update( ...
        x_t, ...
        0.5 / dxy, ...
        waypoints, ...
        wp_index ...
    );
    carrot_store(:, i) = carrot_t;
    if wp_index == length(waypoints);
        wp_index = 1;
        lap_time = t(i)
    end
        
    
    % update steering
    delta_t = calculate_delta(x_t, carrot_t, delta_max);

    % update bicycle
    x_t = bicycle_update(x_t, v_t, L, delta_t, dt);
    x_store(:, i + 1) = x_t;
end

plot_waypoints(1, waypoints);
plot_trajectory(1, x_store, carrot_store, t);

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%