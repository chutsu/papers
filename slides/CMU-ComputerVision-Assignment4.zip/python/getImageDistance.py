import numpy as np
from utils import chi2dist

def get_image_distance(hist1, histSet, method):

    # -----fill in your implementation here --------


    # ----------------------------------------------

    return dist
