import numpy as np


def get_image_features(wordMap, dictionarySize):

    # -----fill in your implementation here --------


    # ----------------------------------------------
    
    return h
