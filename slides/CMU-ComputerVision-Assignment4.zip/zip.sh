#!/bin/bash

zip -FSr soln4.zip . -x ".*" -x "__MACOSX" -x "*Icon*" -x "assgn4.pdf" -x "./data/*"

