#!/bin/bash

zip -FSr soln3.zip . -x ".*" -x "__MACOSX" -x "*Icon*" -x "assgn3.pdf"
