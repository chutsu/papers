function NCVind = findNonConvVertices(poly,cw)
% This functions generates a structure that contains a list of all
% non-convex vertices, and includes the adjacent vertices that define the
% non-convexity and the slopes of the two lines segments.

NCVind= [];
n=length(poly(:,1));

% Check poly is correct orientation
dir = ispolycw(poly(:,1),poly(:,2));
if ((~dir)&&cw)
    [poly(:,1),poly(:,2)] = poly2cw(poly(:,1),poly(:,2));
elseif (dir&&(~cw))
    [poly(:,1),poly(:,2)] = poly2ccw(poly(:,1),poly(:,2));
end

% Close poly + one
poly2 = [poly(end,:);poly;poly(1,:)];
ncvCount = 0;
% For each element of poly
for i=2:n+1
    % Generate line segment vectors
    s1 = poly2(i,:) - poly2(i-1,:);
    in1 = [s1(2), -s1(1)];
    s2 = poly2(i+1,:) - poly2(i,:);
    %Test for vertex non-convexity by taking dot product of segments
    if (in1*s2'<0.0)
        ncvCount = ncvCount+1;
        NCVind(ncvCount) = i-1;
    end
end
