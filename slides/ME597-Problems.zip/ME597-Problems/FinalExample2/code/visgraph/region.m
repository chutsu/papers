B = [ 0 0; 2 0; 1 1];
O = [0.2 0.1; 0.8 0.1; 0.5 0.4; ];
 
R = [B; B(1,:); NaN NaN; O; O(1,:)];

figure(1); clf; hold on;
plot(R(:,1),R(:,2));

boundary = [3 0; 12 0; 12 6; 17 1; 19 14; 17 20; 17 25; 12 20; 6 24; 1 19; 4 16; 0 7];
obstacle1 = [6 17; 8 19; 7 20; 4 18];
obstacle2 = [5 3; 6 2; 8 6; 7 9; 4 9 ];
obstacle3 = [ 9 10; 12 13; 14 9; 15 14; 17 14; 15 19; 13 17; 8 16; 10 12];

map = [boundary; boundary(1,:); NaN NaN; 
       obstacle1; obstacle1(1,:); NaN NaN;
       obstacle2; obstacle2(1,:); NaN NaN;
       obstacle3; obstacle3(1,:); NaN NaN];

figure(2); clf; hold on;
plot(map(:,1),map(:,2));
axis([-1 20 -1 26])