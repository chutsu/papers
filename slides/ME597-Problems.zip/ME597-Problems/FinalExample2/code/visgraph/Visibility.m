%% Visibility graph
clear all; close all; clc

% Set up environment
boundary = [3 0; 12 0; 12 6; 17 1; 19 14; 17 20; 17 25; 12 20; 6 24; 1 19; 4 16; 0 7];
obstacle{1} = [6 17; 8 19; 7 20; 4 18];
obstacle{2} = [5 3; 6 2; 8 6; 7 9; 4 9 ];
obstacle{3}= [ 9 10; 12 13; 14 9; 15 14; 17 14; 15 19; 13 17; 8 16; 10 12];

map = [boundary; boundary(1,:); NaN NaN; 
       obstacle{1}; obstacle{1}(1,:); NaN NaN;
       obstacle{2}; obstacle{2}(1,:); NaN NaN;
       obstacle{3}; obstacle{3}(1,:); NaN NaN];

   
% boundary = [ 0 0; 2 0; 1 1];
% obstacle{1} = [0.2 0.1; 0.8 0.1; 0.5 0.4; ];

startPos = [4 1];
endPos = [16 22];

% Create visibility graph
tic;
numObsts = length(obstacle);
NCV = 1;
if (NCV)
    % Remove nonconvex vertices from boundary
    ncvout = findNonConvVertices(boundary,1);
    allGraphPts =  boundary(ncvout+1,:);
    for i=1:numObsts
        ncvout = findNonConvVertices(obstacle{i},0);
        
        allGraphPts = [allGraphPts;obstacle{i}(ncvout,:)];
    end
else
    allGraphPts = boundary;
    for i=1:numObsts
        allGraphPts = [allGraphPts;obstacle{i}];
    end
end
allGraphPts = [allGraphPts; startPos; endPos];
n = length(allGraphPts(:,1));



% Set initial link possibilities
A = zeros(n,n);

% Check for collisions among links
for i=1:n-1
    for j=i+1:n
        inColl = 0;
        % In collision if the link intersects the boundary
        inColl = inColl + EdgePolyIntersect(allGraphPts([i j],:),boundary);
        % In collision if the link midpoint is outside the boundary
        mid = (allGraphPts(i,:) + allGraphPts(j,:))/2;
        inColl = inColl + ~inpolygon(mid(1), mid(2), boundary(:,1), boundary(:,2));
        for k = 1:numObsts
            % In collision if the link intersects any obstacle
            inColl = inColl + EdgePolyIntersect([allGraphPts(i,:); allGraphPts(j,:)],obstacle{k});
            % In collision if the link midpoint is inside an obstacle
            inColl = inColl + inpolygon(mid(1), mid(2), obstacle{k}(:,1), obstacle{k}(:,2));
        end

        if (~inColl)
            A(i,j) = 1;
            A(j,i) = 1;
            D(i,j) = norm(allGraphPts(i,:)-allGraphPts(j,:));
            D(j,i) = D(i,j);
        end

    end
end
toc;

% Shortest path search
tic;
[spath,sdist] = shortestpath(allGraphPts, A, n-1,n)
toc;

figure(2); clf; hold on;
plot(map(:,1),map(:,2));
for i=1:3
    patch(obstacle{i}(:,1),obstacle{i}(:,2), 'b');
end
axis([-1 20 -1 26])


for i=1:n
    for j=i+1:n
        if (A(i,j))
            figure(2); hold on;
            plot([allGraphPts(i,1) allGraphPts(j,1)],[allGraphPts(i,2) allGraphPts(j,2)],'m');

        end
    end
end
plot(map(:,1),map(:,2));
plot(startPos(1),startPos(2), 'co', 'MarkerSize', 10, 'LineWidth', 3)
plot(endPos(1),endPos(2), 'rx', 'MarkerSize', 10, 'LineWidth', 3)
plot(allGraphPts(spath,1),allGraphPts(spath,2),'g', 'LineWidth',2)

