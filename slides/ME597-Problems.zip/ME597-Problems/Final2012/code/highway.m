%% Highway position estimation
% distances in m

% Tower locations
N = 5;
dx = 1000;
x = [0:dx:N*dx];
y = 500*ones(1,length(x));
towers = [x x+500; y -y];
radius = 1000;

% Lane locations
a = (N+1)*dx;
lane_lines = [0 a 0 a 0 a 0 a 0 a 0 a 0 a 0 a;
              -25 -25 -20 -20 -15 -15 -10 -10 10 10 15 15 20 20 25 25];

% Car location
car = [0 -22.5 0];

% Scene
figure(1); clf; hold on;
plot(towers(1,:), towers(2,:), 'bo');
for i=1:2*(N+1)
    circle(1,towers(:,i),1000);
end

for i=1:8
    plot(lane_lines(1,2*(i-1)+1:2*i),lane_lines(2,2*(i-1)+1:2*i), 'b--');
end
axis([0 (N+1)*dx -600 600]);
axis equal