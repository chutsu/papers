%% kinectsurface.m
% Generates the surface to map and the position of the sensor.


% Kinect pose
xk = [ 1 3 3 0 0 0];  % X,Y,Z,roll,pitch,yaw.

% Define Surface
dxyz = 0.1; %Grid size
xyz = 6; % Grid range
N = xyz/dxyz; % Number of cells
[Y,Z] = meshgrid(0:dxyz:xyz); % Surface points
X = -0.3*sin(4*Y+Z); % Surface values

% Move surface to in front of Kinect
dist = 4;
X = X + dist + xk(1);

% Occupancy grid
voxelgrid = zeros(N,N,N);
for y = 1:N
    for z = 1:N
        xs = round(X(y,z)/dxyz);
        voxelgrid(xs:end,y,z) = 1;
    end
end
% figure(3);clf;
% for x = N-50:N
%     imagesc(squeeze(voxelgrid(x,:,:)));
%     pause(0.1);
% end

vert_fov = deg2rad(43);
vert_diff = vert_fov / 48;
vert_min = -(vert_fov / 2);
vert_max = vert_fov / 2;
% vert_range = vert_min:vert_diff:vert_max;
vert_range = 0:vert_diff:vert_fov;

phi_fov = deg2rad(57);
phi_diff = phi_fov / 64;
phi_min = -(phi_fov / 2);
phi_max = phi_fov / 2;
phi_range = phi_min:phi_diff:phi_max;
% horiz_range = 0:horiz_diff:horiz_fov;

xyz_pairs = zeros(3, length(vert_range) * length(phi_range));

% generate max yaw pitch pairings
counter = 1;
rmax = 6;
for j = 1:1
    for i = 1:length(phi_range)
%         xyz_pairs(:, counter) = [
%             xk(1) + rmax * sin(horiz_range(i)) * cos(vert_range(j)); 
%             xk(2) + rmax * sin(horiz_range(i)) * sin(vert_range(j)); 
%             xk(3) + rmax * cos(horiz_range(i));
%         ];

         xyz_pairs(:, counter) = [
            xk(1) + rmax * sin(phi_range(i)) * cos(deg2rad(10)); 
            xk(2) + rmax * sin(phi_range(i)) * sin(deg2rad(10)); 
            xk(3) + rmax * cos(phi_range(i));
        ];
    

        counter = counter + 1;
    end
end


% Define planar measurement window for visualization
x1 = [5 3 3];
dy = dist * tan((57 / 2) * pi/180);
dz = dist * tan((43 / 2) * pi/180);
window = [
    x1 + [0 dy dz];
    x1 + [0 -dy dz];
    x1 + [0 -dy -dz];
    x1 + [0 dy -dz];
    x1 + [0 dy dz]
];

% Plotting
figure(1); clf; hold on;
surf(X,Y,Z);
plot3(xk(1), xk(2), xk(3), 'ro', 'MarkerSize',6)
plot3(window(:,1),window(:,2),window(:,3), 'k--', 'LineWidth',2)
grid on;
axis([0 xyz 0 xyz 0 xyz]);


% generate x y pairings
for i = 1:length(xyz_pairs)
    point = xyz_pairs(:, i);
    [bham_x, bham_y, bham_z] = bresenham_line3d(xk(1:3), point', 2);
    plot3(bham_x, bham_y, bham_z, 'y');
    xlabel('x-axis');
    ylabel('y-axis');
    zlabel('z-axis');
    
    
    % for i = 1:length(Z)
    %     if (voxelgrid(X(i), Y(i), Z(i)) == 1) 
    %         disp('Found it!');
    %         [X(i), Y(i), Z(i)]
    %     end
    % end
end

