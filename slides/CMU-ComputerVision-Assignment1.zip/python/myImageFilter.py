import numpy as np

def myImageFilter(img0, h):
    # YOUR CODE HERE
