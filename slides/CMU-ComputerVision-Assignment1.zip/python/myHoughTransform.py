import numpy as np

def myHoughTransform(Im, rhoRes, thetaRes):
    # YOUR CODE HERE
