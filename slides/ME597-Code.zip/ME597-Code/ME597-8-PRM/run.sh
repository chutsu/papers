octave prm.m
